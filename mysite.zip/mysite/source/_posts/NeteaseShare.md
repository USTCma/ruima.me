---
title: 创造亿级产品——网易产品经理经验分享会
date: 2017-02-20 18:20:12
tags: [总结,产品经理]
categories: '总结'
description: 网易云课堂产品经理微专业学习小结
photos:
---
最近在网易云课堂学习了[创造亿级产品——网易产品经理经验分享会](http://study.163.com/course/introduction/1537001.htm#/courseDetail)课程，挑选比较有价值的内容，总结分享如下：

## 浅谈产品数据分析

![浅谈产品数据分析](http://oqsovnm36.bkt.clouddn.com/dataanalysis.png)

## 网易产品经理成长记

![网易产品经理成长记](http://oqsovnm36.bkt.clouddn.com/PMgrowing.png)

## 跨境电商入门浅谈

![跨境电商入门浅谈](http://oqsovnm36.bkt.clouddn.com/跨境电商入门.png)

## 产品经理最容易走入的几个误区

内容较浅，无新意，暂无总结

## PM晋升之路与产品设计

内容较浅，无新意，暂无总结