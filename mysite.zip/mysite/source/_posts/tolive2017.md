---
title: 2017，活着
date: 2017-12-30 18:54:23
tags: [总结]
categories: '总结'
description: 2017，从上海来到了杭州，开启了新的生活。
photos: 
---

2017年，离开上海，来到了杭州。为了房子、票子向生活低了头。

原想总结点啥，却发现提笔啥都写不出来。就这样吧，活着，比啥都好。

2018，不再做梦，不再永远年轻，不再永远热泪盈眶。只希望升职加薪、希望家人健康、希望买房买车。

愿在杭州可以过得更好。

<iframe height=auto width=auto src='http://player.youku.com/embed/XNjIxNjMwMTQw' frameborder=0 'allowfullscreen'></iframe>