---
title: 再看大话西游
date: 2016-06-08 16:20:00
tags: [电影]
categories: '电影'
description: “你看那个人，好奇怪哟，象一条狗！”总有一天，我们也会走在路上，象一条狗。
photos:
---
端午节，在家又刷了一遍大话西游，每次重看，总感觉会理解更深一些。也许不至于笑着笑着就哭了，但在笑过之后，终归会心情沉重。有时候，看电影和听歌，其实都是看自己、听自己。

一年前的6月，我离开深圳腾讯，去了北京百度。离开前，我和一个人说，等我，我一定会回来。然而，时至今日，我也没能回去。

知乎上有个提问：为何我年龄越大，看周星驰的电影就越心酸？点赞数最高的答案结尾写道：究其原因，我们都变成了我们当初讨厌的模样。

“你看那个人，好奇怪哟，象一条狗！” 

总有一天，我们也会走在路上，象一条狗。

前不久，66岁的卢冠延重新唱响了《一生所爱》。听着歌，想到已经白发自卑了一辈子的星爷，默默点上了一根烟。

不多说，听歌。

<div style="text-align: center;">
<embed src="http://static.video.qq.com/TPout.swf?vid=k0199hnmf8m&auto=0" allowFullScreen="true" quality="high" width="640" height="480" align="middle" allowScriptAccess="always" type="application/x-shockwave-flash">
</div>