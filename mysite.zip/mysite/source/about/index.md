---
title: Rui's Resume
date: 2017-05-30 22:39:43
comments: false
---
## Experience
Product Manager
[Alibaba Group](http://www.alibabagroup.com/cn/global/home)
Hangzhou China @ Jun. 2017 to Now

Product Manager
[China Reading](http://www.yuewen.com/)
Shanghai China @ Dec. 2015 to Jun. 2017

Product Assistant
[Baidu](https://www.baidu.com/)
Beijing China @ Aug. 2015 to Oct. 2015

Quality Testing Assistant
[Tencent](http://www.tencent.com/zh-cn/index.shtml)
Shenzhen China @ Jul. 2014 to May. 2015

## Education
MSc in information security
[University of Science and Technology of China](http://www.ustc.edu.cn/)
Hefei China @ Jul. 2014 to May. 2015

BSc in software engineering
[EastChina JiaoTong University](http://www.ecjtu.jx.cn/)
Nanchang China @ Jul. 2014 to May. 2015

## Skills
Product Design : <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-half-o"></i>
iOS / Android / Web / Web App

User Experience Design : <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-half-o"></i>
Sketch / Photoshop / Illustrator / Lightroom

Research and Development : <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-half-o"></i>

Software development : <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-half-o"></i>
OOP Python 2, Version control (Git/Github)

Web development : <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i>
Python, HTML/CSS, Javascript and Ruby

Data Analysis and visualisation : <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-half-o"></i><i class="fa fa-star-o"></i>
Python (pandas, matplotlib, ...)

Database management : <i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i>
Relational (MySQL and SQLite3)

## Award
IBM Information Services Management Certificate
Eagles Project Award on Tencent
Best intern for the third quarter of 2015 on Baidu

## Interests Hobbies
Music/Violin/Reading/Movies/Travel

## Contact Me
Email : [i_marui@foxmail.com](mailto:i_marui@foxmail.com)
Add : [Yuhang District, Hangzhou, Zhejiang](https://goo.gl/maps/3K8V65aZBzA2)
WeChat : i-marui

<hr>

<a href=" "><button type="button" style="border:none;background:#DDDDDD;display:block"><b>Download</b></button></a>
